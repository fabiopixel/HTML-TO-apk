package com.fabiopixel.brewpop;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.io.PrintWriter;
import java.io.StringWriter;

public class MainActivity extends Activity {

    private static final String START_URL = "file:///android_asset/index.html";
    private static final String PREFS = "brewpop_diag";
    private static final String LAST_CRASH = "last_crash";
    private static final String LAST_PHASE = "last_phase";

    private WebView webView;
    private String phase = "START";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        installCrashRecorder();

        SharedPreferences prefs = getSharedPreferences(PREFS, MODE_PRIVATE);
        String previousCrash = prefs.getString(LAST_CRASH, "");
        String previousPhase = prefs.getString(LAST_PHASE, "");

        if (previousCrash != null && !previousCrash.isEmpty()) {
            showDiagnostic(
                    "CRASH PRECEDENTE",
                    "Fase: " + previousPhase + "\n\n" + previousCrash,
                    true
            );
            return;
        }

        try {
            phase = "WINDOW_FLAGS";
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

            phase = "CREATE_WEBVIEW";
            webView = new WebView(this);
            webView.setBackgroundColor(Color.BLACK);
            webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
            webView.setVerticalScrollBarEnabled(false);
            webView.setHorizontalScrollBarEnabled(false);

            phase = "WEBVIEW_SETTINGS";
            WebSettings settings = webView.getSettings();
            settings.setJavaScriptEnabled(true);
            settings.setDomStorageEnabled(true);
            settings.setDatabaseEnabled(true);
            settings.setSupportZoom(false);
            settings.setBuiltInZoomControls(false);
            settings.setDisplayZoomControls(false);
            settings.setMediaPlaybackRequiresUserGesture(false);
            settings.setTextZoom(100);
            settings.setAllowFileAccess(true);
            settings.setAllowContentAccess(true);

            phase = "ANDROID_BRIDGE";
            webView.addJavascriptInterface(new AndroidBridge(this), "AndroidBridge");

            phase = "WEBVIEW_CLIENTS";
            webView.setWebChromeClient(new WebChromeClient());
            webView.setWebViewClient(new WebViewClient());

            phase = "SET_CONTENT_VIEW";
            setContentView(webView);

            phase = "LOAD_INDEX";
            if (savedInstanceState == null) {
                webView.loadUrl(START_URL);
            } else {
                webView.restoreState(savedInstanceState);
            }

            phase = "POST_IMMERSIVE";
            webView.postDelayed(() -> {
                try {
                    applyImmersiveMode();
                } catch (Throwable t) {
                    // Immersive must never kill the game.
                }
            }, 700);

            phase = "RUNNING";
        } catch (Throwable t) {
            showDiagnostic("ERRORE AVVIO", stackTrace(t), false);
        }
    }

    private void installCrashRecorder() {
        final Thread.UncaughtExceptionHandler old =
                Thread.getDefaultUncaughtExceptionHandler();

        Thread.setDefaultUncaughtExceptionHandler((thread, throwable) -> {
            try {
                getSharedPreferences(PREFS, MODE_PRIVATE)
                        .edit()
                        .putString(LAST_PHASE, phase)
                        .putString(LAST_CRASH, stackTrace(throwable))
                        .commit();
            } catch (Throwable ignored) {
            }

            if (old != null) {
                old.uncaughtException(thread, throwable);
            }
        });
    }

    private static String stackTrace(Throwable t) {
        try {
            StringWriter sw = new StringWriter();
            PrintWriter pw = new PrintWriter(sw);
            t.printStackTrace(pw);
            pw.flush();
            return sw.toString();
        } catch (Throwable ignored) {
            return String.valueOf(t);
        }
    }

    private void showDiagnostic(String title, String detail, boolean canRetry) {
        try {
            if (webView != null) {
                try {
                    webView.destroy();
                } catch (Throwable ignored) {
                }
                webView = null;
            }

            ScrollView scroll = new ScrollView(this);
            scroll.setBackgroundColor(Color.rgb(8, 9, 20));

            LinearLayout box = new LinearLayout(this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(36, 56, 36, 56);
            box.setGravity(Gravity.CENTER_HORIZONTAL);

            TextView h = new TextView(this);
            h.setText("BREW//POP DIAGNOSTICA\n" + title);
            h.setTextColor(Color.rgb(255, 224, 120));
            h.setTextSize(22f);
            h.setGravity(Gravity.CENTER);
            box.addView(h);

            TextView body = new TextView(this);
            body.setText("\nFase corrente: " + phase + "\n\n" + detail);
            body.setTextColor(Color.WHITE);
            body.setTextSize(12f);
            body.setTextIsSelectable(true);
            box.addView(body);

            if (canRetry) {
                Button retry = new Button(this);
                retry.setText("CANCELLA ERRORE E RIPROVA");
                retry.setOnClickListener(v -> {
                    getSharedPreferences(PREFS, MODE_PRIVATE)
                            .edit()
                            .remove(LAST_CRASH)
                            .remove(LAST_PHASE)
                            .apply();
                    recreate();
                });
                box.addView(retry);
            }

            scroll.addView(box);
            setContentView(scroll);
        } catch (Throwable ignored) {
        }
    }

    private void applyImmersiveMode() {
        try {
            Window window = getWindow();

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                WindowManager.LayoutParams lp = window.getAttributes();
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                window.setAttributes(lp);
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                window.setDecorFitsSystemWindows(false);
                WindowInsetsController controller = window.getInsetsController();
                if (controller != null) {
                    controller.hide(WindowInsets.Type.statusBars()
                            | WindowInsets.Type.navigationBars());
                    controller.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                }
            } else {
                window.getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                                | View.SYSTEM_UI_FLAG_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                                | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (webView != null) {
            try {
                webView.onResume();
            } catch (Throwable ignored) {
            }
        }
        try {
            applyImmersiveMode();
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onPause() {
        if (webView != null) {
            try {
                webView.onPause();
            } catch (Throwable ignored) {
            }
        }
        super.onPause();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            try {
                applyImmersiveMode();
            } catch (Throwable ignored) {
            }
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        if (webView != null) {
            try {
                webView.saveState(outState);
            } catch (Throwable ignored) {
            }
        }
        super.onSaveInstanceState(outState);
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            try {
                webView.removeJavascriptInterface("AndroidBridge");
                webView.stopLoading();
                webView.destroy();
            } catch (Throwable ignored) {
            }
            webView = null;
        }
        super.onDestroy();
    }

    public static class AndroidBridge {
        private final Activity activity;

        AndroidBridge(Activity activity) {
            this.activity = activity;
        }

        @JavascriptInterface
        public void copyText(final String text) {
            activity.runOnUiThread(() -> {
                ClipboardManager clipboard =
                        (ClipboardManager) activity.getSystemService(
                                Context.CLIPBOARD_SERVICE);
                if (clipboard != null) {
                    clipboard.setPrimaryClip(
                            ClipData.newPlainText("BREW//POP Duel", text));
                }
            });
        }

        @JavascriptInterface
        public void shareText(final String title, final String text) {
            activity.runOnUiThread(() -> {
                Intent intent = new Intent(Intent.ACTION_SEND);
                intent.setType("text/plain");
                intent.putExtra(Intent.EXTRA_SUBJECT, title);
                intent.putExtra(Intent.EXTRA_TEXT, text);
                activity.startActivity(Intent.createChooser(intent, title));
            });
        }
    }
}
